import React,{ useEffect, useState, useRef } from 'react'
import axios from 'axios'
import Layout from '../components/Layout';
import Video from './Video';
import Login from './Login';
import { NavLink } from 'react-router-dom';
import '../App.css';


const products = [
    { id: 1, name: 'Genre', category: 'Genre', price: 199.99 },
    { id: 2, name: 'Title', category: 'Title', price: 29.99 },
    { id: 3, name: 'Broadcast', category: 'Broadcast', price: 149.99 },
    { id: 4, name: 'Artist', category: 'Artist', price: 9.99 },
    // Add more products as needed
  ];

function HomePage() {

    const [categoryFilter, setCategoryFilter] = useState('');
    const [priceFilter, setPriceFilter] = useState('');
    const filteredProducts = products.filter((product) =>
        product.category.toLowerCase().includes(categoryFilter.toLowerCase()) &&
        (priceFilter === '' || product.price <= parseFloat(priceFilter))
    );

    return(
        <>
        <Layout>
            <div className='row mt-4'>
                <div className='d-flex justify-content-end'>
                    <NavLink className="login-btn" to='/login'>Login</NavLink>
                </div>
            </div>
            <div className='row'>
                <Video></Video>
            </div>
            <div className='row'>
                <div className="filters">
                    <input
                        type="text"
                        placeholder="Filter by category"
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value)}
                    />
                    <input
                        type="number"
                        placeholder="Filter by max price"
                        value={priceFilter}
                        onChange={(e) => setPriceFilter(e.target.value)}
                    />
                </div>
                <ul>
                    {filteredProducts.map((product) => (
                        <li key={product.id}>
                            {product.name} - ${product.price}
                        </li>
                    ))}
                </ul>
            </div>
        </Layout>
        </>
    );
}
export default HomePage;